﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Web.Models
{
    public class CategoryViewModel
    {
        public int CategoryId { get; set; }
        [Required(ErrorMessage = "A descrição da categoria é obrigatória", AllowEmptyStrings = false)]
        [MaxLength(30, ErrorMessage ="O tamanho máximo do campo é de 30 caracteres")]
        [Display(Name = "Descrição Categoria")]
        public string CategoryDescription { get; set; }
    }
}

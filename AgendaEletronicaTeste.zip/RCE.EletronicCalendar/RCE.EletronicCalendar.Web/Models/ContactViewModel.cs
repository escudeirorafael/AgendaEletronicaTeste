﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Web.Models
{
    public class ContactViewModel
    {
        [Display(Name = "Código")]
        public int IdContact { get; set; }
        [Required(ErrorMessage = "O nome é obrigatório", AllowEmptyStrings = false)]
        [MaxLength(80)]
        [Display(Name = "Nome")]
        public string NameContact { get; set; }
        [Required(ErrorMessage = "O endereço é obrigatório", AllowEmptyStrings = false)]
        [MaxLength(240)]
        [Display(Name = "Endereço")]
        public string Address { get; set; }
        [Required(ErrorMessage = "O Telefone é obrigatório", AllowEmptyStrings = false)]
        [MaxLength(15)]
        [Display(Name = "Telefone")]
        public string PhoneNumber { get; set; }
        [Required(ErrorMessage = "A data de nascimento é obrigatória", AllowEmptyStrings = false)]
        [Display(Name = "Data Nascimento")]
        public DateTime DateBirth { get; set; }
        [Required(ErrorMessage = "Selecione uma categoria", AllowEmptyStrings = false)]
        [Display(Name = "Categoria")]
        public int IdCategory { get; set; }
        [Display(Name = "Categoria")]
        public string Category { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using RCE.EletronicCalendar.App.Interfaces;
using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using RCE.EletronicCalendar.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Web.Controllers
{
    public class ContactController : Controller
    {
        private readonly IContactAppService _contactAppService;
        private readonly ICategoryAppService _categoryAppService;

        public ContactController(IContactAppService contactAppService, ICategoryAppService categoryAppService)
        {
            _contactAppService = contactAppService;
            _categoryAppService = categoryAppService;
        }

        public IActionResult Index(string search)
        {
            if (search != null && search != string.Empty)
            {
                List<Contact> contact = _contactAppService.GetAll().Where(a=>a.NameContact.ToUpper().Contains(search.ToUpper())).ToList();
                return View(contact);
            }
            else {
                List<Contact> contact = _contactAppService.GetAll();
                return View(contact);
            }

            
        }

        public ActionResult Create()
        {
            ViewBag.Category = _categoryAppService.GetAll();
            var model = new ContactViewModel();
            return View(model);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ContactViewModel model)
        {

            if (ModelState.IsValid)
            {
                ContactParam contactParam = new ContactParam();
                contactParam.NameContact = model.NameContact;
                contactParam.Address = model.Address;
                contactParam.PhoneNumber = model.PhoneNumber;
                contactParam.IdCategory = model.IdCategory;
                contactParam.DateBirth = model.DateBirth;

                var idCreate = _contactAppService.Add(contactParam);

                return RedirectToAction("Index");
            }
            // Se ocorrer um erro retorna para pagina
            ViewBag.Category = _categoryAppService.GetAll();
            return View(model);
        }

        public ActionResult Edit(int? id)
        {
            Contact contact = _contactAppService.GetById(id);

            ViewBag.Category = _categoryAppService.GetAll();
            return View(contact);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Contact model)
        {
            if (ModelState.IsValid)
            {

                ContactParam contactParam = new ContactParam();
                contactParam.NameContact = model.NameContact;
                contactParam.Address = model.Address;
                contactParam.PhoneNumber = model.PhoneNumber;
                contactParam.IdCategory = model.IdCategory;
                contactParam.DateBirth = model.DateBirth;
                contactParam.IdContact = model.IdContact;

                var update = _contactAppService.Update(contactParam);
                return RedirectToAction("Index");
            }

            return View(model);
        }

        public ActionResult Delete(int? id)
        {
            Contact contact = _contactAppService.GetById(id);

            ViewBag.Category = _categoryAppService.GetAll();
            return View(contact);
        }
        // POST: Produtos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ContactParam contactParam = new ContactParam();
            Contact contact = _contactAppService.GetById(id);
            contactParam.IdCategory = contact.IdCategory;
            contactParam.IdContact = id;

            _contactAppService.Delete(contactParam);

            return RedirectToAction("Index");
        }

        public ActionResult Details(int? id)
        {
            Contact contact = _contactAppService.GetById(id);

            ViewBag.Category = _categoryAppService.GetAll();
            return View(contact);

        }
    }
}

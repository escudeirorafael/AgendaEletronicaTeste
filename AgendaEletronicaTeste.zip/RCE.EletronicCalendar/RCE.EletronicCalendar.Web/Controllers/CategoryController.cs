﻿using Microsoft.AspNetCore.Mvc;
using RCE.EletronicCalendar.App.Interfaces;
using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using RCE.EletronicCalendar.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;



namespace RCE.EletronicCalendar.Web.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ICategoryAppService _categoryAppService;
        private readonly IContactAppService _contactAppService;

        public CategoryController(ICategoryAppService categoryAppService, IContactAppService contactAppService)
        {
            _categoryAppService = categoryAppService;
            _contactAppService = contactAppService;
        }

 
        public IActionResult Index(string search)
        {

      
            if (search != string.Empty && search != null)
            {
                var categorys = _categoryAppService.GetAll();

                return View(categorys.Where(a => a.CategoryDescription.ToUpper().Contains(search.ToUpper())).ToList());
                
            }
            else
            {
                var categorys = _categoryAppService.GetAll();
                return View(categorys);
            }
        }


            public ActionResult Create()
        {
            ViewBag.Category = new CategoryParam();
            var model = new CategoryViewModel();
            return View(model);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CategoryViewModel model)
        {

            if (ModelState.IsValid)
            {
                var categoryParam = new CategoryParam();
                categoryParam.CategoryDescription = model.CategoryDescription;

                var idCreate = _categoryAppService.Add(categoryParam);

                return RedirectToAction("Index");
            }
            // Se ocorrer um erro retorna para pagina
            ViewBag.Categories = new CategoryParam();
            return View(model);
        }


        public ActionResult Edit(int? id)
        {

            Category category = _categoryAppService.GetById(id);            
            return View(category);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Category model)
        {
            if (ModelState.IsValid)
            {
                var category = _categoryAppService.GetById(model.IdCategory);
                CategoryParam param = new CategoryParam();
                param.CategoryDescription = model.CategoryDescription;
                param.CategoryId = model.IdCategory;

                var update = _categoryAppService.Update(param);
                return RedirectToAction("Index");
            }
            
            return View(model);
        }

        public ActionResult Delete(int? id)
        {
            Category category = _categoryAppService.GetById(id);
            return View(category);
        }
        // POST: Produtos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {

            if (_contactAppService.GetAll().Where(a => a.IdCategory == id).Count() > 0)
            {

                ViewBag.Error = "Não foi possível deletar a categoria, pois ela está atribuída a um contato existente.";
                ModelState.AddModelError("", "Não foi possível deletar a categoria, pois ela está atribuída a um contato existente.");
                Category category = _categoryAppService.GetById(id);
                return View(category);
            }
            else {
                CategoryParam param = new CategoryParam();
                param.CategoryId = id;
                _categoryAppService.Delete(param);

                return RedirectToAction("Index");
            }

            

   
        }


        // GET: Produtos/Details/5
        public ActionResult Details(int? id)
        {


            Category category = _categoryAppService.GetById(id);
            return View(category);
        }
    }
}

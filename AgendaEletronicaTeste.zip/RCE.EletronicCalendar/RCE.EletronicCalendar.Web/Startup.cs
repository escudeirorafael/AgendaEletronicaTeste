using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RCE.EletronicCalendar.App.Interfaces;
using RCE.EletronicCalendar.App.Services;
using RCE.EletronicCalendar.Domain.Interfaces.Repositories;
using RCE.EletronicCalendar.Domain.Interfaces.Services;
using RCE.EletronicCalendar.Domain.Services;
using RCE.EletronicCalendar.Infra.Contracts;
using RCE.EletronicCalendar.Infra.Repositories;
using RCE.EletronicCalendar.Infra.Repositories.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
            RegisterDependencyInjectionServices(services);

        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }

        private void RegisterDependencyInjectionServices(IServiceCollection services)
        {
            services.AddScoped<IDataSettings, DataSettings>();
            services.AddScoped<IDatabaseFactory, DatabaseFactory>();

            services.AddScoped<IContactRepository, ContactRepository>();
            services.AddScoped<IContactService, ContactService>();
            services.AddScoped<IContactAppService, ContactAppService>();


            services.AddScoped<ICategoryRepository, CategoryRepository>();
            services.AddScoped<ICategoryService, CategoryService>();
            services.AddScoped<ICategoryAppService, CategoryAppService>();
        }
    }
}

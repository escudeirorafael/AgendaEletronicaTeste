﻿using System;

namespace RCE.EletronicCalendar.Application
{
    public class Class1
    {
    }
}

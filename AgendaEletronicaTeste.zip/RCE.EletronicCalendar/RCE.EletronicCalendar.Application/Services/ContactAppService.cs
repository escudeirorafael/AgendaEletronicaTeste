﻿using RCE.EletronicCalendar.App.Interfaces;
using RCE.EletronicCalendar.Domain.Interfaces.Services;
using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.App.Services
{
    public class ContactAppService : IContactAppService
    {
        private readonly IContactService _contactService;

        public ContactAppService(IContactService contactService)
        {
            _contactService = contactService;
        }

        public int Add(ContactParam param)
        {
            return _contactService.Add(param);
        }

        public bool Delete(ContactParam param)
        {
            return _contactService.Delete(param);
        }

        public List<Contact> GetAll()
        {
            return _contactService.GetAll();
        }

        public Contact GetById(int? id)
        {
            return _contactService.GetById(id);
        }

        public Contact Update(ContactParam param)
        {
            return _contactService.Update(param);
        }
    }
}

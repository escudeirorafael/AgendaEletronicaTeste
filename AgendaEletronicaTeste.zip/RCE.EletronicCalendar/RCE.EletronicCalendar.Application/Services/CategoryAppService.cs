﻿using RCE.EletronicCalendar.App.Interfaces;
using RCE.EletronicCalendar.Domain.Interfaces.Services;
using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.App.Services
{
    public class CategoryAppService : ICategoryAppService
    {
        public ICategoryService _categoryService;

        public CategoryAppService(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        public Task<int> Add(CategoryParam param)
        {
            return _categoryService.Add(param);
        }

        public Task<bool> Delete(CategoryParam param)
        {
            return _categoryService.Delete(param);
        }

        public List<Category> GetAll()
        {
            return _categoryService.GetAll();
        }

        public Category GetById(int? id)
        {
            return _categoryService.GetById(id);
        }

        public Category Update(CategoryParam param)
        {
            return _categoryService.Update(param);
        }
    }
}

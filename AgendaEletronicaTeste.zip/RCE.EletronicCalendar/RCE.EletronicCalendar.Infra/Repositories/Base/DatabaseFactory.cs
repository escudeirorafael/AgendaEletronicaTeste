﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using RCE.EletronicCalendar.Infra.Contracts;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace RCE.EletronicCalendar.Infra.Repositories.Base
{
    public class DatabaseFactory : IDatabaseFactory
    {
        private IOptions<DataSettings> dataSettings;

        public string ConnectionString => !string.IsNullOrEmpty(dataSettings.Value.DefaultConnection) ?
                                                                dataSettings.Value.DefaultConnection :
                                                                DatabaseConnection.ConnectionConfiguration.GetConnectionString("DefaultConnection");

        public  IDbConnection GetDbConnection => new SqlConnection(ConnectionString);

        

        public DatabaseFactory(IOptions<DataSettings> dataSettings)
        {
            this.dataSettings = dataSettings;
        }
    }
}

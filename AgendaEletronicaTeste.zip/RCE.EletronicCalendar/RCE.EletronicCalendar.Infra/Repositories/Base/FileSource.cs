﻿using RCE.EletronicCalendar.Domain.Enum;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Infra.Repositories.Base
{
    internal sealed class FileSource
    {
        public static string GetFile(string resourceName, ScriptType scriptType)
        {
            try
            {
                var result = string.Empty;

                var assembly = Assembly.GetExecutingAssembly();
                var fileName = GetAssemblyNameFull(resourceName, scriptType);
                var resourceStream = assembly.GetManifestResourceStream(fileName);
                using (var reader = new StreamReader(resourceStream, Encoding.UTF8))
                {
                    result =  reader.ReadToEnd();
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string GetAssemblyNameFull(string resource, ScriptType scriptType)
        {
            var script = new Dictionary<ScriptType, string>
            {
                {ScriptType.Insert,$"RCE.EletronicCalendar.Infra.Scripts.Insert.{resource}.sql" },
                {ScriptType.Delete,$"RCE.EletronicCalendar.Infra.Scripts.Delete.{resource}.sql" },
                {ScriptType.Update,$"RCE.EletronicCalendar.Infra.Scripts.Update.{resource}.sql" },
                {ScriptType.Select,$"RCE.EletronicCalendar.Infra.Scripts.Select.{resource}.sql" },
            };

            return script[scriptType];
        }
    }
}

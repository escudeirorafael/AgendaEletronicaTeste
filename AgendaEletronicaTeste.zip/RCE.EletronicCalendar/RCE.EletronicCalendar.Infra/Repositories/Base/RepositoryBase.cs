﻿using RCE.EletronicCalendar.Infra.Contracts;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace RCE.EletronicCalendar.Infra.Repositories.Base
{
    public class RepositoryBase
    {
        protected readonly IDbConnection dbConn;
        protected IDbTransaction dbTransaction;

        public RepositoryBase(IDatabaseFactory databaseFactory)
        {
            dbConn = databaseFactory.GetDbConnection;
            dbConn.Open();

        }

        public RepositoryBase(IDatabaseFactory databaseFactory, IDbTransaction transaction = null)
        {
            dbConn = databaseFactory.GetDbConnection;
            if(dbConn.State != ConnectionState.Open)
                dbConn.Open();
            dbTransaction = transaction;
        }
    }
}

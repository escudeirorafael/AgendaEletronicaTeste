﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace RCE.EletronicCalendar.Infra.Repositories.Base
{
    public class DatabaseConnection
    {
        public static string  ConnectionString {get;set;}

        public static IConfiguration ConnectionConfiguration
        {
        get
            {
                IConfigurationBuilder builder = new ConfigurationBuilder().SetBasePath(System.IO.Directory.GetCurrentDirectory());

                return builder.AddJsonFile("appsettings.json").Build();
            }
        }

    }
}

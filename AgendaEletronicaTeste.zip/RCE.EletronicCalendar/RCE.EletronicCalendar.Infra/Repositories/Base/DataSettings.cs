﻿using RCE.EletronicCalendar.Infra.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace RCE.EletronicCalendar.Infra.Repositories.Base
{
    public class DataSettings : IDataSettings
    {
        public string DefaultConnection { get; set; }
    }
}

﻿using Dapper;
using RCE.EletronicCalendar.Domain.Interfaces.Repositories;
using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using RCE.EletronicCalendar.Infra.Contracts;
using RCE.EletronicCalendar.Infra.Repositories.Base;
using Slapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Infra.Repositories
{
    public class ContactRepository : RepositoryBase, IContactRepository
    {
        public ContactRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        {
        }

        public int Add(ContactParam param)
        {
            var sql =  FileSource.GetFile("insert_contact", Domain.Enum.ScriptType.Insert);
            var parameters = new DynamicParameters();
            parameters.Add("@NOME", param.NameContact);
            parameters.Add("@ENDERECO", param.Address);
            parameters.Add("@TELEFONE", param.PhoneNumber);
            parameters.Add("@DATA_NASC", param.DateBirth);
            parameters.Add("@ID_CATEGORIA", param.IdCategory);


            dbTransaction = dbConn.BeginTransaction(System.Data.IsolationLevel.Serializable);
            try
            {
                var resultID =  dbConn.ExecuteScalar<int>(sql, parameters, dbTransaction);
                dbTransaction.Commit();

                return resultID;
            }
            catch (Exception ex)
            {
                dbTransaction.Rollback();
                throw;
            }
        }


        public Contact Update(ContactParam param)
        {
            var oldValue = GetById(param.IdContact);

            var sql =  FileSource.GetFile("update_contact", Domain.Enum.ScriptType.Update);
            var parameters = new DynamicParameters();
            parameters.Add("@ID_CONTATO", param.IdContact);
            parameters.Add("@NOME", param.NameContact);
            parameters.Add("@ENDERECO", param.Address);
            parameters.Add("@TELEFONE", param.PhoneNumber);
            parameters.Add("@DATA_NASC", param.DateBirth);
            parameters.Add("@ID_CATEGORIA", param.IdCategory);
            parameters.Add("@ID_CATEGORIA_ORIG", oldValue.IdCategory);

            dbTransaction = dbConn.BeginTransaction(System.Data.IsolationLevel.Serializable);
            try
            {
                dbConn.Execute(sql, parameters, dbTransaction);
                dbTransaction.Commit();

                Contact CT = new Contact();
                return CT;
            }
            catch (Exception ex)
            {
                dbTransaction.Rollback();
                throw;
            }
        }

        public bool Delete(ContactParam param)
        {
            var sql =  FileSource.GetFile("delete_contact", Domain.Enum.ScriptType.Delete);
            var parameters = new DynamicParameters();
            parameters.Add("@ID_CONTATO", param.IdContact);
            parameters.Add("@ID_CATEGORIA", param.IdCategory);


            dbTransaction = dbConn.BeginTransaction(System.Data.IsolationLevel.Serializable);
            try
            {
                dbConn.Execute(sql, parameters, dbTransaction);
                dbTransaction.Commit();

                
                return true;
            }
            catch (Exception ex)
            {
                dbTransaction.Rollback();
                return false;
                throw;
            }
        }

        public List<Contact> GetAll()
        {
            var sql =  FileSource.GetFile("select_contact", Domain.Enum.ScriptType.Select); 
            var parameters = new DynamicParameters();
                        
            try
            {
                var result =  dbConn.Query<dynamic>(sql, parameters);
                List<Contact> lst = AutoMapper.MapDynamic<Contact>(result).ToList();

                return lst;
            }
            catch (Exception ex)
            {
                
                throw;
            }
        }

        public Contact GetById(int? id)
        {
            var sql =  FileSource.GetFile("select_contact_id", Domain.Enum.ScriptType.Select); 
            var parameters = new DynamicParameters();
            parameters.Add("@ID_CONTATO", id);
            try
            {
                var result = dbConn.Query<dynamic>(sql, parameters);
                Contact contact = AutoMapper.MapDynamic<Contact>(result).FirstOrDefault();

                return contact;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

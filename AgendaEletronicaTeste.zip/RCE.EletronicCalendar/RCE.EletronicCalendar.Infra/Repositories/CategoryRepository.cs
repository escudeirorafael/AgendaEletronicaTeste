﻿using Dapper;
using RCE.EletronicCalendar.Domain.Interfaces.Repositories;
using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using RCE.EletronicCalendar.Infra.Contracts;
using RCE.EletronicCalendar.Infra.Repositories.Base;
using Slapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Infra.Repositories
{
    public class CategoryRepository : RepositoryBase, ICategoryRepository
    {
        public CategoryRepository(IDatabaseFactory databaseFactory) : base(databaseFactory)
        {
        }

        public async Task<int> Add(CategoryParam param)
        {
            var sql =  FileSource.GetFile("insert_category", Domain.Enum.ScriptType.Insert);
            var parameters = new DynamicParameters();
            parameters.Add("@DESCRICAO", param.CategoryDescription);


            dbTransaction = dbConn.BeginTransaction(System.Data.IsolationLevel.Serializable);
            try
            {
                var resultID = dbConn.ExecuteScalar<int>(sql, parameters, dbTransaction);
                dbTransaction.Commit();

                return resultID;
            }
            catch (Exception ex)
            {
                dbTransaction.Rollback();
                throw;
            }
        }


        public  Category Update(CategoryParam param)
        {
            var sql =  FileSource.GetFile("update_category", Domain.Enum.ScriptType.Update);
            var parameters = new DynamicParameters();
            parameters.Add("@ID_CATEGORIA", param.CategoryId);
            parameters.Add("@DESCRICAO", param.CategoryDescription);

            dbTransaction = dbConn.BeginTransaction(System.Data.IsolationLevel.Serializable);
            try
            {
                dbConn.Execute(sql, parameters, dbTransaction);
                dbTransaction.Commit();

                Category CT = GetById(param.CategoryId);
                return CT;
            }
            catch (Exception ex)
            {
                dbTransaction.Rollback();
                throw;
            }
        }

        public async Task<bool> Delete(CategoryParam param)
        {
            var sql =  FileSource.GetFile("delete_category", Domain.Enum.ScriptType.Delete);
            var parameters = new DynamicParameters();
            parameters.Add("@ID_CATEGORIA", param.CategoryId);


            dbTransaction = dbConn.BeginTransaction(System.Data.IsolationLevel.Serializable);
            try
            {
                dbConn.Execute(sql, parameters, dbTransaction);
                dbTransaction.Commit();


                return true;
            }
            catch (Exception ex)
            {
                dbTransaction.Rollback();
                return false;
                throw;
            }
        }

        public List<Category> GetAll()
        {
            var sql =  FileSource.GetFile("select_category", Domain.Enum.ScriptType.Select); //"EXEC INCLUIR_CONTATO @NOME='TESTILDO',@ENDERECO='RUA DAS COUVES',@TELEFONE='123456789',@DATA_NASC = NULL, @ID_CATEGORIA=1";
            var parameters = new DynamicParameters();
 

            //dbTransaction = dbConn.BeginTransaction(System.Data.IsolationLevel.Serializable);
            try
            {
                var result = dbConn.Query<dynamic>(sql, parameters);
                //dbTransaction.Commit();

                List<Category> lst = AutoMapper.MapDynamic<Category>(result).ToList();

                return lst;
            }
            catch (Exception ex)
            {
                //dbTransaction.Rollback();
                throw;
            }
        }

        public  Category GetById(int? id)
        {
            var sql =  FileSource.GetFile("select_category_id", Domain.Enum.ScriptType.Select);
            var parameters = new DynamicParameters();
            parameters.Add("@ID_CATEGORIA", id);
            try
            {
                var result = dbConn.Query<dynamic>(sql, parameters);
                Category contact = AutoMapper.MapDynamic<Category>(result).FirstOrDefault();

                return contact;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

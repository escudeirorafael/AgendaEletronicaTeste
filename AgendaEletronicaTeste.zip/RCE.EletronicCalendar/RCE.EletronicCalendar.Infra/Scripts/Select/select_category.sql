SELECT 
ID as IdCategory,
CATEGORIA AS CategoryDescription
FROM CATEGORIA;
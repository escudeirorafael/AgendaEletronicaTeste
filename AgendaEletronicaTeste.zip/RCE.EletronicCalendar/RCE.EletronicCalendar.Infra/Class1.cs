﻿using System;

namespace RCE.EletronicCalendar.Infra
{
    public class Class1
    {
    }
}

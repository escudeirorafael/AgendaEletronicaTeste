﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace RCE.EletronicCalendar.Infra.Contracts
{
    public interface IDatabaseFactory
    {
        IDbConnection GetDbConnection { get; }
    }
}

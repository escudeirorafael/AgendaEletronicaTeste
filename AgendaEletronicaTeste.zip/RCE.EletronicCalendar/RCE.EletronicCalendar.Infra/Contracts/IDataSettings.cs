﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RCE.EletronicCalendar.Infra.Contracts
{
    public interface IDataSettings
    {
        string DefaultConnection { get; set; }
    }
}

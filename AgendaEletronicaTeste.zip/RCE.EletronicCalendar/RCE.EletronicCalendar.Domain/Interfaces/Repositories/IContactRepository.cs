﻿using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Domain.Interfaces.Repositories
{
    public interface IContactRepository
    {
        int Add(ContactParam param);
        Contact Update(ContactParam param);
        bool Delete(ContactParam param);
        List<Contact> GetAll();
        Contact GetById(int? id);


    }
}

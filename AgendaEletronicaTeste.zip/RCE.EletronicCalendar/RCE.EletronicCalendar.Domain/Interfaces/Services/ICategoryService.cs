﻿using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Domain.Interfaces.Services
{
    public interface ICategoryService
    {
        Category GetById(int? id);

        List<Category> GetAll();
        Task<bool> Delete(CategoryParam param);

        Category Update(CategoryParam param);
        Task<int> Add(CategoryParam param);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RCE.EletronicCalendar.Domain.Enum
{
    public enum  ScriptType
    {
        Insert = 1,
        Delete = 2,
        Update = 3,
        Select = 4
    }
}

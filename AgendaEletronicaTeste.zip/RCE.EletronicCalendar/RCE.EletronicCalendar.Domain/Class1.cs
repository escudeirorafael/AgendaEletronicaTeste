﻿using System;

namespace RCE.EletronicCalendar.Domain
{
    public class Class1
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RCE.EletronicCalendar.Domain.Models
{
    public class Category
    {
        [Display(Name = "Código Categoria")]
        public int IdCategory { get; set; }
        [Required(ErrorMessage = "A descrição da categoria é obrigatória", AllowEmptyStrings = false)]
        [MaxLength(30, ErrorMessage = "O tamanho máximo do campo é de 30 caracteres")]
        [Display(Name = "Descrição Categoria")]
        public string CategoryDescription { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RCE.EletronicCalendar.Domain.Models.Param
{
    public class ContactParam
    {
        public int? IdContact { get; set; }
        public string NameContact { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime DateBirth { get; set; }

        public int IdCategory { get; set; }

    }
}

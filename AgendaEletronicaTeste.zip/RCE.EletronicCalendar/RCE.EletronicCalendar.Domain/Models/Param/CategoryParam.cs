﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RCE.EletronicCalendar.Domain.Models.Param
{
    public class CategoryParam
    {
        [Display(Name = "Código Categoria")]
        public int? CategoryId { get; set; }

        [Display(Name = "Descrição Categoria")]
        public string CategoryDescription { get; set; }
    }
}

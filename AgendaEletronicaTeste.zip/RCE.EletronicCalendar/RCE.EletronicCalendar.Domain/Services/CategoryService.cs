﻿using RCE.EletronicCalendar.Domain.Interfaces.Repositories;
using RCE.EletronicCalendar.Domain.Interfaces.Services;
using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Domain.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository _categoryRepository;
        public CategoryService(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }


        public Task<int> Add(CategoryParam param)
        {
            return _categoryRepository.Add(param);
        }

        public Task<bool> Delete(CategoryParam param)
        {
            return _categoryRepository.Delete(param);
        }

        public List<Category> GetAll()
        {
            return _categoryRepository.GetAll();
        }

        public Category GetById(int? id)
        {
            return _categoryRepository.GetById(id);
        }

        public Category Update(CategoryParam param)
        {
            return _categoryRepository.Update(param);
        }
    }
}

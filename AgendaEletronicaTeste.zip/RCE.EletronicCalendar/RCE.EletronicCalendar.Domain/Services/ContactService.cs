﻿using RCE.EletronicCalendar.Domain.Interfaces.Repositories;
using RCE.EletronicCalendar.Domain.Interfaces.Services;
using RCE.EletronicCalendar.Domain.Models;
using RCE.EletronicCalendar.Domain.Models.Param;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RCE.EletronicCalendar.Domain.Services
{
    public class ContactService : IContactService
    {
        private readonly IContactRepository _contactRepository;

        public ContactService(IContactRepository contactRepository)
        {
            _contactRepository = contactRepository;
        }

        public int Add(ContactParam param)
        {
            return _contactRepository.Add(param);
        }

        public bool Delete(ContactParam param)
        {
            return _contactRepository.Delete(param);
        }

        public List<Contact> GetAll()
        {
            return _contactRepository.GetAll();
        }

        public Contact GetById(int? id)
        {
            return _contactRepository.GetById(id);
        }

        public Contact Update(ContactParam param)
        {
            return _contactRepository.Update(param);
        }
    }
}
